import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class StudentData {

    static class Student {
        String name;
        int age;
        String studentId;

        public Student(String name, int age, String studentId) {
            this.name = name;
            this.age = age;
            this.studentId = studentId;
        }

        public String toString() {
            return Objects.toString("Name: " + name + ", Age: " + age + ", StudentID: " + studentId);
        }
    }

    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();

        students.add(new Student("Ayesha", 20, "ST12345"));
        students.add(new Student("Ali", 22, "ST12346"));
        students.add(new Student("Sara", 21, "ST12347"));

        System.out.println("Student Data:");
        for (Student s : students) {
            System.out.println(s.toString());
        }
    }
}
