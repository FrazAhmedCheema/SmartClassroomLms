public class Student1 {

    public static int findMax(int[] numbers) {
        int max = numbers[0];
        for (int num : numbers) {
            if (num > max) {
                max = num;
            }
        }
        return max;
    }

    public static double calculateAverage(int[] numbers) {
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        return (double) sum / numbers.length;
    }

    public static void printStats(int[] numbers) {
        System.out.println("Max value: " + findMax(numbers));
        System.out.println("Average: " + calculateAverage(numbers));
    }

    public static void main(String[] args) {
        int[] data = {23, 45, 67, 12, 89, 34};
        printStats(data);
    }
}
