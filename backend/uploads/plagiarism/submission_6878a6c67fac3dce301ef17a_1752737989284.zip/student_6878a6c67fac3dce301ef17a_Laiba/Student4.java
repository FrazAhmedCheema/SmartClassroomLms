public class Student4 {

    public static int sumOfElements(int[] nums) {
        int total = 0;
        for (int val : nums) {
            total += val;
        }
        return total;
    }

    public static double computeAverage(int[] nums) {
        int totalSum = sumOfElements(nums);
        return (double) totalSum / nums.length;
    }

    public static void printResults(int[] nums) {
        System.out.println("Total: " + sumOfElements(nums));
        System.out.println("Mean: " + computeAverage(nums));
    }

    public static void main(String[] args) {
        int[] sampleData = {7, 14, 21, 28, 35};
        printResults(sampleData);
    }
}
