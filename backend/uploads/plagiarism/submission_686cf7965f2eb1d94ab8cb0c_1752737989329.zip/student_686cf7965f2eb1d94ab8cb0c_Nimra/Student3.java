public class Student3 {

    public static int findMax(int[] input) {
        int max = input[0];
        for (int value : input) {
            if (value > max) {
                max = value;
            }
        }
        return max;
    }

    public static int findMin(int[] input) {
        int min = input[0];
        for (int value : input) {
            if (value < min) {
                min = value;
            }
        }
        return min;
    }

    public static void printMinMax(int[] input) {
        System.out.println("Max: " + findMax(input));
        System.out.println("Min: " + findMin(input));
    }

    public static void main(String[] args) {
        int[] numbers = {5, 15, 25, 35, 45};
        printMinMax(numbers);
    }
}
