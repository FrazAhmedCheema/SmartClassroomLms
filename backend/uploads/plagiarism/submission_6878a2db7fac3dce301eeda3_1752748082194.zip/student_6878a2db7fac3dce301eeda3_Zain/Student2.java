public class Student2 {

    public static int findMaxValue(int[] array) {
        int max = array[0];
        for (int element : array) {
            if (element > max) {
                max = element;
            }
        }
        return max;
    }

    public static double getAverage(int[] array) {
        int total = 0;
        for (int element : array) {
            total += element;
        }
        return (double) total / array.length;
    }

    public static void displayStatistics(int[] array) {
        System.out.println("Maximum: " + findMaxValue(array));
        System.out.println("Average: " + getAverage(array));
    }

    public static void main(String[] args) {
        int[] values = {10, 20, 30, 40, 50, 60};
        displayStatistics(values);
    }
}
