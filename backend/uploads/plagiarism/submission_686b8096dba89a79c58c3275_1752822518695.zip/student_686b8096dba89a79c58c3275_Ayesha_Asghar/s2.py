# largest_number_v2.py

def get_largest_value(array):
    if len(array) == 0:
        print("Empty list provided.")
        return None

    return max(array)

# Example call
data = [3, 7, 1, 9, 5, 12, 4]
maximum = get_largest_value(data)
print("Maximum value found:", maximum)
