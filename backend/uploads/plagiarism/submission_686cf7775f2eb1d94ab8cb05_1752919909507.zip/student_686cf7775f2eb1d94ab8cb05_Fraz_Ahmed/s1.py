# largest_number_v1.py

def find_max_number(numbers):
    if not numbers:
        return None  # Handle empty list

    largest = numbers[0]
    for num in numbers:
        if num > largest:
            largest = num
    return largest

# Example usage
arr = [3, 7, 1, 9, 5, 12, 4]
print("The largest number is:", find_max_number(arr))
