class Person {
    // Attribute for name
    private String name;
    
    // One-to-one association with CNIC
    private CNIC cnic;

    // Constructor to initialize Person with a name and a CNIC
    public Person(String name, CNIC cnic) {
        this.name = name;
        this.cnic = cnic;
    }

    // Getter method for Person's name
    public String getName() {
        return name;
    }

    // Setter method for Person's name
    public void setName(String name) {
        this.name = name;
    }

    // Getter method for CNIC
    public CNIC getCnic() {
        return cnic;
    }

    // Setter method for CNIC
    public void setCnic(CNIC cnic) {
        this.cnic = cnic;
    }

    @Override
    public String toString() {
        return "Person Name: " + name + ", " + cnic.toString();
    }
}